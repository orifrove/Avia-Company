#!/bin/bash
# Запусти этот скрипт из папки Avia-Company
# chmod +x fix_repo.sh && ./fix_repo.sh

echo "🔧 Удаляю лишние файлы из git..."

# Удалить из git tracking (не удаляет файлы с диска)
git rm --cached .env 2>/dev/null && echo "✅ .env убран из git"
git rm --cached db.sqlite3 2>/dev/null && echo "✅ db.sqlite3 убран из git"
git rm -r --cached venv/ 2>/dev/null && echo "✅ venv/ убран из git"
git rm -r --cached apps/**/__pycache__ 2>/dev/null
git rm -r --cached core/__pycache__ 2>/dev/null
find . -name "__pycache__" | xargs git rm -r --cached 2>/dev/null
find . -name "*.pyc" | xargs git rm --cached 2>/dev/null

echo "📝 Делаю коммит..."
git add .gitignore .env.example README.md
git add -A
git commit -m "fix: remove sensitive files, add .gitignore and README"

echo "🚀 Пушу на GitHub..."
git push origin main

echo ""
echo "✅ Готово! Репозиторий очищен и обновлён."
