# ✈️ Avia Company — Flight Booking REST API

A Django REST API for managing flights, bookings, aircraft, and payments for an aviation company.

## Tech Stack

- **Backend:** Python 3.12, Django 6.0, Django REST Framework
- **Auth:** JWT (SimpleJWT)
- **Database:** PostgreSQL
- **Docs:** Swagger UI (drf-spectacular)
- **Other:** django-filter, django-cors-headers, python-decouple

## Features

- User registration & JWT authentication
- Flight search by city and date
- Seat booking with passenger details (passport, phone)
- Aircraft management
- Payment types with pricing
- Admin panel with full CRUD
- Swagger API documentation at `/api/docs/`

## Project Structure

```
apps/
├── users/       # Registration, login, JWT auth
├── flights/     # Flight listings, search, management commands
├── bookings/    # Booking creation and management
├── aircraft/    # Aircraft models
└── payments/    # Payment types and pricing
core/            # Django settings, urls, wsgi
```

## Quick Start

```bash
# 1. Clone the repo
git clone https://github.com/orifrove/Avia-Company.git
cd Avia-Company

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set up environment variables
cp .env.example .env
# Edit .env with your database credentials

# 5. Run migrations
python manage.py migrate

# 6. (Optional) Fill database with sample data
python manage.py fill_db

# 7. Create superuser
python manage.py createsuperuser

# 8. Run the server
python manage.py runserver
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register/` | Register new user |
| POST | `/api/auth/login/` | Get JWT tokens |
| POST | `/api/auth/refresh/` | Refresh access token |
| GET | `/api/flights/` | List all flights |
| POST | `/api/bookings/` | Create a booking |
| GET | `/api/aircraft/` | List aircraft |
| GET | `/api/payments/` | List payment types |

Full API docs: `http://localhost:8000/api/docs/`

## Environment Variables

Copy `.env.example` to `.env` and fill in your values:

```
SECRET_KEY=your-secret-key
DEBUG=True
DB_NAME=avia_db
DB_USER=postgres
DB_PASSWORD=your_password
```
